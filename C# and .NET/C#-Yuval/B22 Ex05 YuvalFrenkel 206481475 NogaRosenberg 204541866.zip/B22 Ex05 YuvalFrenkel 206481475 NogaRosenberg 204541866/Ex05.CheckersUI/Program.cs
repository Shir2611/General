﻿using System.Windows.Forms;

namespace Ex05.CheckersUI
{
    internal class Program
    {
        // $G$ SFN-012 (+12) Bonus:  Rich ui + improvement for the ai.
      
        public static void Main()
        {
            Application.EnableVisualStyles();
            new UIManager();
        }
    }
}
