﻿using System;
using System.Collections.Generic;

namespace Ex02_Checkers
{
    internal class Board
    {
       
        // $G$ DSN-999 (-3) Data structures should be readonly.
        private Checker[][] m_Board;
        private Player m_WhitePlayer;
        private Player m_BlackPlayer;

        internal Board(Player i_WhitePlayer, Player i_BlackPlayer, int i_BoardSize)
        {
            m_WhitePlayer = i_WhitePlayer;
            m_BlackPlayer = i_BlackPlayer;
            Size = i_BoardSize;
            m_Board = getBoardArray(i_BoardSize);

            spawnCheckers();
        }

        /*
         * A private constructor that receives the checkers array field.
         */
        private Board(Player i_WhitePlayer, Player i_BlackPlayer, Checker[][] i_Board)
        {
            m_WhitePlayer = i_WhitePlayer;
            m_BlackPlayer = i_BlackPlayer;
            m_Board = i_Board;
            Size = m_Board.Length;
        }

        internal int Size { get; }

        internal Checker[][] Snapshot { get => m_Board; }

        internal Move LastMove { get; private set; }

        /*
         * Creates and returns a new instance of Board, where the m_Board field and the Player fields are cloned with a *deep copy*.
         */
        internal Board GetClone(Player i_WhitePlayer, Player i_BlackPlayer)
        {
            Checker[][] clonedBoard = getBoardArray(Size);
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    if (m_Board[i][j] != null)
                    {
                        clonedBoard[i][j] = m_Board[i][j].GetClone();
                        if (clonedBoard[i][j].Team == Checker.eTeams.White)
                        {
                            i_WhitePlayer.CheckerList.Add(clonedBoard[i][j]);
                        }
                        else
                        {
                            i_BlackPlayer.CheckerList.Add(clonedBoard[i][j]);
                        }
                    }
                }
            }

            return new Board(i_WhitePlayer, i_BlackPlayer, clonedBoard);
        }

        internal void PerformMove(Move i_Move)
        {
            LastMove = i_Move;
            m_Board[i_Move.TargetPosition[0]][i_Move.TargetPosition[1]] = i_Move.Checker;
            i_Move.Checker.Position = i_Move.TargetPosition;
            m_Board[i_Move.StartPosition[0]][i_Move.StartPosition[1]] = null;
            if (i_Move.IsEating)
            {
                Checker eatenChecker = m_Board[i_Move.EatenCheckerPosition[0]][i_Move.EatenCheckerPosition[1]];
                m_Board[i_Move.EatenCheckerPosition[0]][i_Move.EatenCheckerPosition[1]] = null;
                if (eatenChecker.Team == Checker.eTeams.White)
                {
                    m_WhitePlayer.CheckerList.Remove(eatenChecker);
                }
                else
                {
                    m_BlackPlayer.CheckerList.Remove(eatenChecker);
                }
            }

            if (isBecomingKing(i_Move))
            {
                i_Move.Checker.Type = Checker.eTypes.King;
            }
        }

        internal List<Move> GetPossibleMoves(Player i_Player)
        {
            List<Move> possibleMoves = GetPossibleEatingMoves(i_Player);
            if (possibleMoves.Count == 0)
            {
                possibleMoves.AddRange(GetPossibleRegularMoves(i_Player));
            }

            return possibleMoves;
        }

        internal List<Move> GetPossibleRegularMoves(Player i_Player)
        {
            List<Move> playerPossibleRegularMoves = new List<Move>();
            foreach (Checker checker in i_Player.CheckerList)
            {
                int direction = 1 - ((int)checker.Team * 2);
                bool isEatingMoves = false;
                List<Move> checkerPossibleRegularMoves = getPossibleMoves(i_Player, checker, isEatingMoves, direction);
                playerPossibleRegularMoves.AddRange(checkerPossibleRegularMoves);
                if (checker.Type == Checker.eTypes.King)
                {
                    direction *= -1;
                    List<Move> checkerPossibleRegularMovesOppositeDirection = getPossibleMoves(i_Player, checker, isEatingMoves, direction);
                    playerPossibleRegularMoves.AddRange(checkerPossibleRegularMovesOppositeDirection);
                }
            }

            return playerPossibleRegularMoves;
        }

        internal List<Move> GetPossibleEatingMoves(Player i_Player)
        {
            List<Move> playerPossibleEatingMoves = new List<Move>();
            foreach (Checker checker in i_Player.CheckerList)
            {
                int direction = 1 - ((int)checker.Team * 2);
                bool isEatingMoves = true;
                List<Move> checkerPossibleEatingMoves = getPossibleMoves(i_Player, checker, isEatingMoves, direction);
                playerPossibleEatingMoves.AddRange(checkerPossibleEatingMoves);
                if (checker.Type == Checker.eTypes.King)
                {
                    direction *= -1;
                    List<Move> checkerPossibleRegularMovesOppositeDirection = getPossibleMoves(i_Player, checker, isEatingMoves, direction);
                    playerPossibleEatingMoves.AddRange(checkerPossibleRegularMovesOppositeDirection);
                }
            }

            return playerPossibleEatingMoves;
        }

        internal Move GetRandomPossibleMove(Player i_Player)
        {
            Random randomGenerator = new Random();
            int randomIndex;
            Move randomMove;

            List<Move> possibleEatingMoves = GetPossibleEatingMoves(i_Player);
            if (possibleEatingMoves.Count > 0)
            {
                randomIndex = randomGenerator.Next(0, possibleEatingMoves.Count);
                randomMove = possibleEatingMoves[randomIndex];
            }
            else
            {
                List<Move> possibleRegularMoves = GetPossibleRegularMoves(i_Player);
                randomIndex = randomGenerator.Next(0, possibleRegularMoves.Count);
                randomMove = possibleRegularMoves[randomIndex];
            }

            return randomMove;
        }

        internal Move GetRandomEatingPossibleMove(Player i_Player)
        {
            List<Move> possibleMoves = GetPossibleEatingMoves(i_Player);
            Random randomGenerator = new Random();
            int randomIndex = randomGenerator.Next(0, possibleMoves.Count);
            return possibleMoves[randomIndex];
        }

        internal bool AnyPossibleEatingMoves(Player i_Player)
        {
            List<Move> possibleEatingMoves = GetPossibleEatingMoves(i_Player);
            return possibleEatingMoves.Count > 0;
        }

        internal bool AnyPossibleMoves(Player i_Player)
        {
            List<Move> possibleMoves = GetPossibleMoves(i_Player);
            return possibleMoves.Count > 0;
        }

        private bool isPositionInBounds(int[] i_Position)
        {
            return i_Position[0] < Size && i_Position[0] >= 0 && i_Position[1] < Size && i_Position[1] >= 0;
        }

        private void spawnCheckers()
        {
            m_WhitePlayer.CheckerList = new HashSet<Checker>();
            m_WhitePlayer.Team = Checker.eTeams.White;
            m_BlackPlayer.CheckerList = new HashSet<Checker>();
            m_BlackPlayer.Team = Checker.eTeams.Black;

            for (int i = 0; i < 2 + ((Size - 6) / 2); i++)
            {
                for (int j = (i + 1) % 2; j < m_Board[0].Length; j += 2)
                {
                    Checker newChecker = new Checker(new int[] { i, j }, Checker.eTeams.Black);
                    m_Board[i][j] = newChecker;
                    m_BlackPlayer.CheckerList.Add(newChecker);
                }
            }

            for (int i = m_Board.Length - 1; i >= m_Board.Length - 2 - ((Size - 6) / 2); i--)
            {
                for (int j = (i + 1) % 2; j < m_Board[0].Length; j += 2)
                {
                    Checker newChecker = new Checker(new int[] { i, j }, Checker.eTeams.White);
                    m_Board[i][j] = newChecker;
                    m_WhitePlayer.CheckerList.Add(newChecker);
                }
            }
        }

        private bool isBecomingKing(Move i_Move)
        {
            return (i_Move.TargetPosition[0] == 0 && i_Move.Checker.Team == Checker.eTeams.White) || (i_Move.TargetPosition[0] == Size - 1 && i_Move.Checker.Team == Checker.eTeams.Black);
        }

        private List<Move> getPossibleMoves(Player i_Player, Checker i_Checker, bool i_EatingMoves, int i_Direction)
        {
            List<Move> possibleMoves = new List<Move>();
            int jumpDistance = 1;

            if (i_EatingMoves)
            {
                jumpDistance = 2;
            }

            for (int j = -1; j <= 1; j += 2)
            {
                int[] targetPosition = new int[2] { i_Checker.Position[0] + (jumpDistance * i_Direction), i_Checker.Position[1] + (jumpDistance * j * i_Direction) };
                if (isPositionInBounds(targetPosition))
                {
                    int[][] moveCoordinates = new int[2][];
                    moveCoordinates[0] = i_Checker.Position;
                    moveCoordinates[1] = targetPosition;
                    Move possibleMove = new Move(moveCoordinates, Snapshot, i_Player, LastMove);
                    if (possibleMove.IsValid)
                    {
                        possibleMoves.Add(possibleMove);
                    }
                }
            }

            return possibleMoves;
        }

        private Checker[][] getBoardArray(int i_BoardSize)
        {
            Checker[][] boardArray = new Checker[i_BoardSize][];
            for (int i = 0; i < i_BoardSize; i++)
            {
                boardArray[i] = new Checker[i_BoardSize];
            }

            return boardArray;
        }
    }
}