﻿namespace Ex02_Checkers
{
    internal class Checker
    {
        internal Checker(int[] i_Position, eTeams i_Team)
        {
            Position = i_Position;
            Team = i_Team;
            Type = eTypes.Regular;
        }

        internal Checker(int[] i_Position, eTeams i_Team, eTypes i_Type)
            : this(i_Position, i_Team)
        {
            Type = i_Type;
        }

        internal enum eTypes
        {
            Regular = 1,
            King = 4,
        }

        internal enum eTeams
        {
            Black = 0,
            White = 1,
        }

        internal int[] Position { get; set; }

        internal eTypes Type { get; set; }

        internal eTeams Team { get; }

        /*
         * Creates and returns a *deep copy* of this checker.
         */
        internal Checker GetClone()
        {
            Checker clonedChecker = new Checker((int[])Position.Clone(), Team, Type);
            return clonedChecker;
        }
    }
}
