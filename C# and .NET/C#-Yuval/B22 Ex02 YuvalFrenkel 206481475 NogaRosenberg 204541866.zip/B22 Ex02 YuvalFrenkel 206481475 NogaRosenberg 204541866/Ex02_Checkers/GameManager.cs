﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Ex02_Checkers
{
    internal class GameManager
    {
        private Board m_Board;
        private eGameModes m_GameMode;

        internal GameManager(string i_FirstUserName, eGameModes i_GameMode, int i_BoardSize, string i_SecondUserName)
        {
            m_GameMode = i_GameMode;
            initPlayers(i_FirstUserName, i_SecondUserName, i_GameMode);
            m_Board = new Board(WhitePlayer, BlackPlayer, i_BoardSize);
            CurrentTurnPlayer = WhitePlayer;
        }

        internal enum eGameModes
        {
            OnePlayer,
            TwoPlayers,
        }

        internal Player CurrentTurnPlayer { get; private set; }

        internal Player WhitePlayer { get; private set; }

        internal Player BlackPlayer { get; private set; }

        internal Move LastMove { get { return m_Board.LastMove; } }

        internal int BoardSize { get => m_Board.Size; }

        internal Checker[][] BoardSnapshot { get => m_Board.Snapshot; }

        internal bool IsCurrentTurnHuman { get { return CurrentTurnPlayer == WhitePlayer || m_GameMode == eGameModes.TwoPlayers; } }

        internal void RestartRound()
        {
            m_Board = new Board(WhitePlayer, BlackPlayer, BoardSize);
            CurrentTurnPlayer = WhitePlayer;
        }

        internal void PerformMove(Move i_Move)
        {
            m_Board.PerformMove(i_Move);
            if (!i_Move.IsContinuous)
            {
                switchTurns();
            }
        }

        internal void PerformComputerMove()
        {
            Thread.Sleep(500);
            performIntelligentComputerMove();
        }

        internal bool IsMoveValid(Move i_Move)
        {
            return i_Move.IsValid && (i_Move.IsEating || !m_Board.AnyPossibleEatingMoves(i_Move.MovingPlayer));
        }

        internal bool IsRoundOver()
        {
            return !m_Board.AnyPossibleMoves(CurrentTurnPlayer);
        }

        internal Player GetWinner()
        {
            Player winner;

            bool blackPlayerHasPossibleMoves = m_Board.AnyPossibleMoves(BlackPlayer);
            bool whitePlayerHasPossibleMoves = m_Board.AnyPossibleMoves(WhitePlayer);

            if (!blackPlayerHasPossibleMoves && !whitePlayerHasPossibleMoves)
            {
                winner = null;
            }
            else if (blackPlayerHasPossibleMoves)
            {
                winner = BlackPlayer;
            }
            else
            {
                winner = WhitePlayer;
            }

            return winner;
        }

        internal void UpdateWinningPlayerScore(Player i_Player)
        {
            int score = 0;
            foreach (Checker checker in i_Player.CheckerList)
            {
                score += (int)checker.Type;
            }

            foreach (Checker checker in GetOppositePlayer(i_Player).CheckerList)
            {
                score -= (int)checker.Type;
            }

            i_Player.GameScore += Math.Abs(score);
        }

        internal Player GetOppositePlayer(Player i_Player)
        {
            if (i_Player == WhitePlayer)
            {
                return BlackPlayer;
            }
            else
            {
                return WhitePlayer;
            }
        }

        private void initPlayers(string i_FirstUserName, string i_SecondUserName, eGameModes i_GameMode)
        {
            WhitePlayer = new Player() { Name = i_FirstUserName, Team = Checker.eTeams.White, IsHuman = true };
            if (i_GameMode == eGameModes.TwoPlayers)
            {
                BlackPlayer = new Player() { Name = i_SecondUserName, Team = Checker.eTeams.Black, IsHuman = true };
            }
            else
            {
                BlackPlayer = new Player() { Name = "Computer", Team = Checker.eTeams.Black, IsHuman = false };
            }
        }

        private void switchTurns()
        {
            CurrentTurnPlayer = GetOppositePlayer(CurrentTurnPlayer);
        }

        /*
         * Implementation of the Minimax algorithm.
         */
        // $G$ SFN-016 (+20) AI Implementation
        private void performIntelligentComputerMove()
        {
            Player maximizingPlayer = CurrentTurnPlayer.GetClone();
            Player minimizingPlayer = GetOppositePlayer(CurrentTurnPlayer).GetClone();
            Board fictionalBoard = m_Board.GetClone(minimizingPlayer, maximizingPlayer);
            Move chosenMove = getMaxEvaluationMove(fictionalBoard, maximizingPlayer, minimizingPlayer);
            chosenMove = chosenMove.GetClone(BoardSnapshot, maximizingPlayer, LastMove);
            PerformMove(chosenMove);
        }

        private Move getMaxEvaluationMove(Board i_FictionalBoard, Player i_MaximizingPlayer, Player i_MinimizingPlayer)
        {
            Move maxEvaluatedMove = null;
            int maxEvaluation = -100;
            List<Move> possibleMoves = i_FictionalBoard.GetPossibleMoves(i_MaximizingPlayer);
            foreach (Move move in possibleMoves)
            {
                Player maximizingPlayer = i_MaximizingPlayer.GetClone();
                Player minimizingPlayer = i_MinimizingPlayer.GetClone();
                Board fictionalBoard = i_FictionalBoard.GetClone(minimizingPlayer, maximizingPlayer);
                int moveEvaluation = evaluateSequence(fictionalBoard, move, maximizingPlayer, minimizingPlayer, 6, false);
                if (moveEvaluation >= maxEvaluation)
                {
                    maxEvaluatedMove = move;
                    maxEvaluation = moveEvaluation;
                }
            }

            return maxEvaluatedMove;
        }
     
        // $G$ CSS-028 (-4) A method should not include more than one return statement.
        private int evaluateSequence(Board i_FictionalBoard, Move i_Move, Player i_MaximizingPlayer, Player i_MinimizingPlayer, int i_Depth, bool i_IsMaximizingPlayer)
        {
            if (i_Depth == 0)
            {
                return i_MaximizingPlayer.CheckerList.Count - i_MinimizingPlayer.CheckerList.Count;
            }

            i_FictionalBoard.PerformMove(i_Move);

            if (i_IsMaximizingPlayer)
            {
                // Get all possible moves
                // foreach (move in possibleMoves): Create a new copy of the board and players,
                List<Move> possibleMoves = i_FictionalBoard.GetPossibleMoves(i_MaximizingPlayer);
                int maxEvaluation = -100;
                foreach (Move move in possibleMoves)
                {
                    Player newMaximizingPlayer = i_MaximizingPlayer.GetClone();
                    Player newMinimizingPlayer = i_MinimizingPlayer.GetClone();
                    Board newFictionalBoard = i_FictionalBoard.GetClone(newMinimizingPlayer, newMaximizingPlayer);
                    int moveEvaluation = evaluateSequence(newFictionalBoard, move, newMaximizingPlayer, newMaximizingPlayer, i_Depth - 1, false);
                    maxEvaluation = Math.Max(maxEvaluation, moveEvaluation);
                }

                return maxEvaluation;
            }
            else
            {
                List<Move> possibleMoves = i_FictionalBoard.GetPossibleMoves(i_MinimizingPlayer);
                int minEvaluation = 100;
                foreach (Move move in possibleMoves)
                {
                    Player newMaximizingPlayer = i_MaximizingPlayer.GetClone();
                    Player newMinimizingPlayer = i_MinimizingPlayer.GetClone();
                    Board newFictionalBoard = i_FictionalBoard.GetClone(newMinimizingPlayer, newMaximizingPlayer);
                    int moveEvaluation = evaluateSequence(newFictionalBoard, move, newMaximizingPlayer, newMaximizingPlayer, i_Depth - 1, true);
                    minEvaluation = Math.Min(minEvaluation, moveEvaluation);
                }

                return minEvaluation;
            }
        }
    }
}
