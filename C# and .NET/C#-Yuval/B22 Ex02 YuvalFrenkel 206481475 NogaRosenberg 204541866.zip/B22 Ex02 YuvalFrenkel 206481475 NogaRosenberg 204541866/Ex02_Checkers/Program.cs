﻿namespace Ex02_Checkers
{
    internal class Program
    {
        public static void Main()
        {
            new GameCanvas();
        }
    }
}
