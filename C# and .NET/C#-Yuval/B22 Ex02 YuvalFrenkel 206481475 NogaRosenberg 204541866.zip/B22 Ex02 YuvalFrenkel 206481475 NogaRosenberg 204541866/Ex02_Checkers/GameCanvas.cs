﻿using System;
using System.Collections.Generic;
using Ex02.ConsoleUtils;

namespace Ex02_Checkers
{
    internal class GameCanvas
    {
        private GameManager m_GameManager;
        private InputManager m_InputManager;

        internal GameCanvas()
        {
            m_InputManager = new InputManager();
            InputManager.InitPackage initPackage = m_InputManager.GetInitPackage();
            m_GameManager = new GameManager(initPackage.FirstUserName, initPackage.GameMode, initPackage.BoardSize, initPackage.SecondUserName);
            play();
        }

        private void play()
        {
            do
            {
                playRound();
                m_GameManager.RestartRound();
            }
            while (m_InputManager.WantNextRound());
            endGame();
        }

        private void playRound()
        {
            Move nextMove;

            while (!m_GameManager.IsRoundOver())
            {
                displayGame();

                if (m_GameManager.IsCurrentTurnHuman)
                {
                    Player currentTurnPlayer = m_GameManager.CurrentTurnPlayer;
                    nextMove = getInputMove(currentTurnPlayer);
                    if (nextMove == null)
                    {
                        return;
                    }

                    m_GameManager.PerformMove(nextMove);
                }
                else
                {
                    Console.WriteLine(string.Format("{0} is thinking...", m_GameManager.CurrentTurnPlayer.Name));
                    m_GameManager.PerformComputerMove();
                }
            }

            endRound();
        }

        private void endGame()
        {
            Console.WriteLine("Game finished. Bye bye!");
        }

        private Move getInputMove(Player i_Player)
        {
            Move inputMove = null;

            int[][] moveCoordinates = m_InputManager.GetNextMove(i_Player.Team, i_Player.Name, m_GameManager.BoardSize);
            if (moveCoordinates == null)
            {
                endRound(m_GameManager.GetOppositePlayer(i_Player));
            }
            else
            {
                inputMove = new Move(moveCoordinates, m_GameManager.BoardSnapshot, i_Player, m_GameManager.LastMove);
                while (!m_GameManager.IsMoveValid(inputMove))
                {
                    m_InputManager.NotifyForbiddenMove();
                    moveCoordinates = m_InputManager.GetNextMove(i_Player.Team, i_Player.Name, m_GameManager.BoardSize);
                    if (moveCoordinates == null)
                    {
                        endRound(m_GameManager.GetOppositePlayer(i_Player));
                    }
                    else
                    {
                        inputMove = new Move(moveCoordinates, m_GameManager.BoardSnapshot, i_Player, m_GameManager.LastMove);
                    }
                }
            }

            return inputMove;
        }

        private void endRound()
        {
            displayGame();
            Player winner = m_GameManager.GetWinner();
            endRound(winner);
        }

        private void endRound(Player i_Winner)
        {
            if (i_Winner == null)
            {
                Console.WriteLine("It's a tie!");
            }
            else
            {
                m_GameManager.UpdateWinningPlayerScore(i_Winner);
                announceWinner(i_Winner.Name, i_Winner.Team);
            }

            announceScoreBalance();
        }

        private void announceWinner(string i_WinnerName, Checker.eTeams i_WinningTeam)
        {
            Console.WriteLine(string.Format("{0} ({1}) wins!", i_WinnerName, i_WinningTeam));
        }

        private void announceScoreBalance()
        {
            Player whitePlayer = m_GameManager.WhitePlayer;
            Player blackPlayer = m_GameManager.BlackPlayer;
            Console.WriteLine(string.Format("{0}'s total score: {1}", whitePlayer.Name, whitePlayer.GameScore));
            Console.WriteLine(string.Format("{0}'s total score: {1}", blackPlayer.Name, blackPlayer.GameScore));
        }

        private void displayGame()
        {
            Screen.Clear();
            Checker[][] boardSnapshot = m_GameManager.BoardSnapshot;
            displayBoard(boardSnapshot);
            if (m_GameManager.LastMove != null)
            {
                printLastMove();
            }
        }

        private void printLastMove()
        {
            Move lastMove = m_GameManager.LastMove;
            string lastMoveString = parseMoveToString(lastMove);
            string lastPlayerSymbol = getPlayerSymbol(lastMove.MovingPlayer);
            Console.WriteLine(string.Format("{0}'s move was ({1}): {2}", lastMove.MovingPlayer.Name, lastPlayerSymbol, lastMoveString));
        }
        // $G$ CSS-999 (-5) Missing blank line before return.
        private string parseMoveToString(Move i_Move)
        {
            string moveString = string.Format("{0}{1}>{2}{3}", (char)('A' + (char)i_Move.StartPosition[1]), (char)('a' + (char)i_Move.StartPosition[0]), (char)('A' + (char)i_Move.TargetPosition[1]), (char)('a' + (char)i_Move.TargetPosition[0]));
            return moveString;
        }

        private string getPlayerSymbol(Player i_Player)
        {
            string symbol;

            if (i_Player.Team == Checker.eTeams.White)
            {
                symbol = "X";
            }
            else
            {
                symbol = "O";
            }

            return symbol;
        }

        private void displayBoard(Checker[][] i_BoardSnapshot)
        {
            int boardSize = i_BoardSnapshot.Length;
            Console.WriteLine(string.Empty);
            drawCapitalLettersRow(boardSize);
            Console.WriteLine(string.Empty);
            drawSeparationLine(boardSize);
            Console.WriteLine(string.Empty);
            for (int i = 0; i < boardSize; i++)
            {
                Console.Write(string.Format("{0}|", (char)('a' + i)));
                for (int j = 0; j < boardSize; j++)
                {
                    Checker currentChecker = i_BoardSnapshot[i][j];
                    if (currentChecker == null)
                    {
                        Console.Write("   |");
                    }
                    else if (currentChecker.Team == Checker.eTeams.White)
                    {
                        if (currentChecker.Type == Checker.eTypes.Regular)
                        {
                            Console.Write(" X |");
                        }
                        else
                        {
                            Console.Write(" Z |");
                        }
                    }
                    else
                    {
                        if (currentChecker.Type == Checker.eTypes.Regular)
                        {
                            Console.Write(" O |");
                        }
                        else
                        {
                            Console.Write(" Q |");
                        }
                    }
                }

                Console.WriteLine(string.Empty);
                drawSeparationLine(boardSize);
                Console.WriteLine(string.Empty);
            }
        }

        private void drawSeparationLine(int i_BoardSize)
        {
            Console.Write(" ");
            for (int i = 0; i <= 4 * i_BoardSize; i++)
            {
                Console.Write("=");
            }
        }

        private void drawCapitalLettersRow(int i_BoardSize)
        {
            for (int i = 0; i < i_BoardSize; i++)
            {
                Console.Write(string.Format("   {0}", (char)('A' + i)));
            }
        }
    }
}
