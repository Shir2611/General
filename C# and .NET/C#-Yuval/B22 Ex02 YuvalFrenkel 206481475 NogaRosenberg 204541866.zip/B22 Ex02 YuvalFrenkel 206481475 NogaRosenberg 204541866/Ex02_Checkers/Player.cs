﻿using System.Collections.Generic;

namespace Ex02_Checkers
{
    internal class Player
    {
        internal string Name { get; set; }

        internal bool IsHuman { get; set; }

        internal HashSet<Checker> CheckerList { get; set; }

        internal int GameScore { get; set; } = 0;

        internal Checker.eTeams Team { get; set; }

        /*
         * Creates and retruns a *deep copy* clone of this Player instance.
         */
        internal Player GetClone()
        {
            Player clonedPlayer = new Player();
            clonedPlayer.CheckerList = new HashSet<Checker>();
            clonedPlayer.Team = Team;
            clonedPlayer.Name = Name;
            return clonedPlayer;
        }
    }

}
