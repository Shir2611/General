﻿using System;
namespace Ex02_Checkers
{
    internal class InputManager
    {
        internal InitPackage GetInitPackage()
        {
            string firstUserName = getFirstUserName();
            GameManager.eGameModes gameMode = getGameMode();
            int boardSize = getBoardSize();
            string secondUserName;
            if (gameMode == 0)
            {
                secondUserName = "Computer";
            }
            else
            {
                secondUserName = getSecondUserName();
            }

            return new InitPackage(firstUserName, gameMode, boardSize, secondUserName);
        }

        internal void NotifyForbiddenMove()
        {
            Console.WriteLine("Forbidden move entered. Please re-enter a move.");
        }

        internal bool WantNextRound()
        {
            string userChoice;

            Console.Write("Would you like to play another round? Choose Y / N: ");
            userChoice = Console.ReadLine();
            while (!isValidYesOrNoInput(userChoice))
            {
                Console.Write("Invalid input entered. Please enter Y or N: ");
                userChoice = Console.ReadLine();
            }

            return userChoice == "Y";
        }

        internal int[][] GetNextMove(Checker.eTeams i_CurrentTurnTeam, string i_CurrentTurnName, int i_BoardSize)
        {
            string moveInput;
            string teamSymbol;

            if (i_CurrentTurnTeam == Checker.eTeams.White)
            {
                teamSymbol = "X";
            }
            else
            {
                teamSymbol = "O";
            }

            Console.Write(string.Format("{0}'s Turn ({1}): ", i_CurrentTurnName, teamSymbol));
            moveInput = Console.ReadLine();
            if (moveInput == "Q")
            {
                return null;
            }

            while (!isValidMove(moveInput, i_BoardSize))
            {
                Console.Write("Invalid move entered. Please re-enter a move in the format COLrow>COLrow (For example: Af>Bg): ");
                moveInput = Console.ReadLine();
            }

            return parseMoveStringToCoordinates(moveInput);
        }

        private string getFirstUserName()
        {
            string firstUserName;

            Console.Write("Hello! Let's play Checkers! Please enter your name (No spaces & up to 10 letters): ");
            firstUserName = Console.ReadLine();
            while (!isValidUserName(firstUserName))
            {
                Console.WriteLine("Invalid name entered. Please enter a name with no spaces that is of length up to 10 letters: ");
                firstUserName = Console.ReadLine();
            }

            return firstUserName;
        }

        private bool isValidUserName(string i_UserName)
        {
            return !i_UserName.Contains(" ") && i_UserName.Length <= 10;
        }

        private GameManager.eGameModes getGameMode()
        {
            string gameMode;

            Console.Write("Please enter 0 to play against the computer or 1 to play against another player: ");
            gameMode = Console.ReadLine();
            while (!isValidGameMode(gameMode))
            {
                Console.Write("Invalid game mode entered. Please enter 0 to play against the computer or 1 to play against another player: ");
                gameMode = Console.ReadLine();
            }

            return (GameManager.eGameModes)int.Parse(gameMode);
        }

        private bool isValidGameMode(string i_GameMode)
        {
            return i_GameMode == "0" || i_GameMode == "1";
        }

        private int getBoardSize()
        {
            string boardSize;
            Console.Write("Please enter the desired board size - 6, 8 or 10: ");
            boardSize = Console.ReadLine();
            while (!isValidBoardSize(boardSize))
            {
                Console.Write("Invalid board size entered. Please enter 6, 8 or 10: ");
                boardSize = Console.ReadLine();
            }

            return int.Parse(boardSize);
        }

        private bool isValidBoardSize(string i_BoardSize)
        {
            return i_BoardSize == "6" || i_BoardSize == "8" || i_BoardSize == "10";
        }

        private string getSecondUserName()
        {
            string secondUserName;

            Console.Write("Please enter the second player's name (No spaces & up to 10 letters): ");
            secondUserName = Console.ReadLine();
            while (!isValidUserName(secondUserName))
            {
                Console.Write("Invalid name entered. Please enter a name with no spaces that is of length up to 10 letters: ");
                secondUserName = Console.ReadLine();
            }

            return secondUserName;
        }

        private bool isValidYesOrNoInput(string i_UserChoice)
        {
            return i_UserChoice == "Y" || i_UserChoice == "N";
        }

        private int[][] parseMoveStringToCoordinates(string i_Move)
        {
            int[][] moveCoordinates = new int[2][];
            moveCoordinates[0] = new int[2] { i_Move[1] - 'a', i_Move[0] - 'A' };
            moveCoordinates[1] = new int[2] { i_Move[4] - 'a', i_Move[3] - 'A' };
            return moveCoordinates;
        }

        private bool isValidMove(string i_Move, int i_BoardSize)
        {
            bool isValid = true;

            if (i_Move.Length != 5)
            {
                isValid = false;
            }
            else if (i_Move[2] != '>')
            {
                isValid = false;
            }
            else if (!isCharInRange(i_Move[0], 'A', i_BoardSize) || !isCharInRange(i_Move[3], 'A', i_BoardSize))
            {
                isValid = false;
            }
            else if (!isCharInRange(i_Move[1], 'a', i_BoardSize) || !isCharInRange(i_Move[4], 'a', i_BoardSize))
            {
                isValid = false;
            }

            return isValid;
        }

        private bool isCharInRange(char i_Char, char i_LowBound, int i_Offset)
        {
            return i_Char >= i_LowBound && i_Char <= (i_LowBound + i_Offset - 1);
        }

        internal class InitPackage
        {
            private string m_FirstUserName;
            private GameManager.eGameModes m_GameMode;
            private int m_BoardSize;
            private string m_SecondUserName;

            public InitPackage(string firstUserName, GameManager.eGameModes gameMode, int boardSize, string secondUserName)
            {
                m_FirstUserName = firstUserName;
                m_GameMode = gameMode;
                m_BoardSize = boardSize;
                m_SecondUserName = secondUserName;
            }

            internal string FirstUserName { get => m_FirstUserName; }

            internal GameManager.eGameModes GameMode { get => m_GameMode; }

            internal int BoardSize { get => m_BoardSize; }

            internal string SecondUserName { get => m_SecondUserName; }
        }
    }
}
