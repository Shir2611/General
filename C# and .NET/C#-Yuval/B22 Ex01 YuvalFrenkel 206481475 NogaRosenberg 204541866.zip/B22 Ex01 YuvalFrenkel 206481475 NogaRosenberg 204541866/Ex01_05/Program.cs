﻿using System;

namespace Ex01_05
{
    internal class Program
    {
        public static void Main()
        {
            string userInputString = getUserInput();

            printOutput(userInputString);
        }

        private static void printOutput(string userInputString)
        {
            printSmallestDigit(userInputString);
            printAverageOfDigits(userInputString);
            printNumOfEvenDigits(userInputString);
            printNumOfDigitsLargerThanUnitDigit(userInputString);
        }

        private static string getUserInput()
        {
            string userInputString;

            Console.WriteLine("Please enter a 7 digits number (and then press Enter):");
            while (true)
            {
                userInputString = Console.ReadLine();
                if (isValidInput(userInputString))
                {
                    return userInputString;
                }

                Console.WriteLine("Invalid input. Please enter a 7 digits number:");
            }
        }

        private static bool isValidInput(string i_UserInputString)
        {
            return i_UserInputString.Length == 7 && containsDigitsOnly(i_UserInputString);
        }

        private static bool containsDigitsOnly(string i_StringInput)
        {
            foreach (char character in i_StringInput)
            {
                if (!((character >= 48) && (character <= 57)))
                {
                    return false;
                }
            }

            return true;
        }

        private static void printSmallestDigit(string i_StringInput)
        {
            Console.WriteLine(string.Format("The smallest digit is {0}", getSmallestDigit(i_StringInput)));
        }

        private static byte getSmallestDigit(string i_StringInput)
        {
            byte smallestDigit = 10;

            foreach (char character in i_StringInput)
            {
                if (character - 48 < smallestDigit)
                {
                    smallestDigit = (byte)(character - 48);
                }
            }

            return smallestDigit;
        }

        private static void printAverageOfDigits(string i_StringInput)
        {
            Console.WriteLine(string.Format("The average of the digits is {0}", getAverageOfDigits(i_StringInput)));
        }

        private static float getAverageOfDigits(string i_StringInput)
        {
            float sumOfDigits = 0;

            foreach (char character in i_StringInput)
            {
                sumOfDigits += character - 48;
            }

            return sumOfDigits / i_StringInput.Length;
        }

        private static void printNumOfEvenDigits(string i_StringInput)
        {
            Console.WriteLine(string.Format("The number of even digits is {0}", getNumOfEvenDigits(i_StringInput)));
        }

        private static byte getNumOfEvenDigits(string i_StringInput)
        {
            byte numOfEvenDigits = 0;

            foreach (char character in i_StringInput)
            {
                if ((character - 48) % 2 == 0)
                {
                    numOfEvenDigits++;
                }
            }

            return numOfEvenDigits;
        }

        private static void printNumOfDigitsLargerThanUnitDigit(string i_StringInput)
        {
            Console.WriteLine(string.Format("The number of digits that are larger than the units digit is {0}", getNumOfDigitsLargerThanUnitsDigit(i_StringInput)));
        }

        private static byte getNumOfDigitsLargerThanUnitsDigit(string i_StringInput)
        {
            byte numOfDigitsLargerThanUnitsDigit = 0;

            foreach (char character in i_StringInput)
            {
                if (character > i_StringInput[i_StringInput.Length - 1])
                {
                    numOfDigitsLargerThanUnitsDigit++;
                }
            }

            return numOfDigitsLargerThanUnitsDigit;
        }
    }
}
