﻿using System;
using System.Linq;

namespace Ex01_01
{
    internal class Program
    {
        public static void Main()
        {
            string[] binaryNumsInput = getUserInput();
            byte[] decimalNumsInput = convertBinaryStringsArrayToDecimalNumsArray(binaryNumsInput);

            printOutput(binaryNumsInput, decimalNumsInput);
        }

        private static string[] getUserInput()
        {
            string[] binaryNumsInput = new string[3];
            int numberOfValidInputs = 0;

            Console.WriteLine("Please type 3 binary numbers with 8 digits each (and then press enter)");
            while (numberOfValidInputs < 3)
            {
                binaryNumsInput[numberOfValidInputs] = Console.ReadLine();
                if (checkBinaryNumbersValidity(binaryNumsInput[numberOfValidInputs]))
                {
                    numberOfValidInputs++;
                }
                else
                {
                    Console.WriteLine("Invalid input; please type a valid binary number (and then press enter)");
                }
            }

            return binaryNumsInput;
        }

        private static void printOutput(string[] i_BinaryNumsInput, byte[] i_DecimalNumsInput)
        {
            Console.WriteLine(string.Format("The decimal numbers are: {0}, {1}, {2}", i_DecimalNumsInput[0], i_DecimalNumsInput[1], i_DecimalNumsInput[2]));
            Console.WriteLine(string.Format("The average number of zeroes is {0}", averageNumOfDigitInBinaryNums(i_BinaryNumsInput, '0')));
            Console.WriteLine(string.Format("The average number of ones is {0}", averageNumOfDigitInBinaryNums(i_BinaryNumsInput, '1')));
            Console.WriteLine(string.Format("There are {0} numbers which are powers of two", countNumOfPowersOfTwo(i_BinaryNumsInput)));
            Console.WriteLine(string.Format("There are {0} numbers which are an ascending series", countNumOfIncreasingSequences(i_DecimalNumsInput)));
            Console.WriteLine(string.Format("There are {0} numbers which are palindromes", countPalindromes(i_DecimalNumsInput)));
            Console.WriteLine(string.Format("The greatest number is {0} and the smallest is {1}", i_DecimalNumsInput.Max(), i_DecimalNumsInput.Min()));
        }

        private static bool checkBinaryNumbersValidity(string i_BinaryString)
        {
            if (i_BinaryString.Length != 8)
            {
                return false;
            }

            for (byte i = 0; i < 8; i++)
            {
                if (i_BinaryString[i] != '1' && i_BinaryString[i] != '0')
                {
                    return false;
                }
            }

            return true;
        }

        private static byte countDigitInBinaryString(string i_BinaryString, char i_Digit)
        {
            byte numOfDigits = 0;

            foreach (char charachter in i_BinaryString)
            {
                if (charachter == i_Digit)
                {
                    numOfDigits++;
                }
            }

            return numOfDigits;
        }

        private static float averageNumOfDigitInBinaryNums(string[] i_BinaryStrings, char i_Digit)
        {
            byte sumOfDigits = 0;

            foreach (string binaryString in i_BinaryStrings)
            {
                sumOfDigits += countDigitInBinaryString(binaryString, i_Digit);
            }

            return (float)sumOfDigits / i_BinaryStrings.Length;
        }

        private static byte countNumOfPowersOfTwo(string[] i_BinaryStrings)
        {
            byte numOfPowersOfTwo = 0;

            foreach (string binaryString in i_BinaryStrings)
            {
                if (countDigitInBinaryString(binaryString, '1') == 1)
                {
                    numOfPowersOfTwo++;
                }
            }

            return numOfPowersOfTwo;
        }

        private static byte countNumOfIncreasingSequences(byte[] i_DecimalNums)
        {
            byte numOfIncreasingSequences = 0;

            foreach (byte num in i_DecimalNums)
            {
                if (isIncreasingSequence(num))
                {
                    numOfIncreasingSequences++;
                }
            }

            return numOfIncreasingSequences;
        }

        private static bool isIncreasingSequence(byte i_DecimalNum)
        {
            byte latestDigit = 10;

            while (i_DecimalNum > 0)
            {
                if (i_DecimalNum % 10 >= latestDigit)
                {
                    return false;
                }

                latestDigit = (byte)(i_DecimalNum % 10);
                i_DecimalNum /= 10;
            }

            return true;
        }

        private static byte countPalindromes(byte[] i_DecimalNumbers)
        {
            byte numberOfPalindromes = 0;

            foreach (byte num in i_DecimalNumbers)
            {
                if (isPalindrome(num))
                {
                    numberOfPalindromes++;
                }
            }

            return numberOfPalindromes;
        }

        private static bool isPalindrome(byte i_DecimalNum)
        {
            string decimalString = i_DecimalNum.ToString();
            byte leftPointer = 0, rightPointer = (byte)(decimalString.Length - 1);

            while (leftPointer < rightPointer)
            {
                if (decimalString[leftPointer] != decimalString[rightPointer])
                {
                    return false;
                }

                leftPointer++;
                rightPointer--;
            }

            return true;
        }

        private static byte convertBinaryStringToDecimalNum(string i_BinaryString)
        {
            byte decimalNum = 0;

            for (int i = i_BinaryString.Length - 1; i >= 0; i--)
            {
                if (i_BinaryString[i] == '1')
                {
                    decimalNum += (byte)Math.Pow(2, i_BinaryString.Length - 1 - i);
                }
            }

            return decimalNum;
        }

        private static byte[] convertBinaryStringsArrayToDecimalNumsArray(string[] i_BinaryStrings)
        {
            byte[] decimalNums = new byte[i_BinaryStrings.Length];

            for (byte i = 0; i < 3; i++)
            {
                decimalNums[i] = convertBinaryStringToDecimalNum(i_BinaryStrings[i]);
            }

            return decimalNums;
        }
    }
}