﻿using System;
using System.Text;

namespace Ex01_02
{
    public class Program
    {
        // $G$ CSS-999 (-10) Missing ConsoleRead() invcoation at the end of the main, can't see the result of the program without it.
        public static void Main()
        {
            printAsteriskClock(5);
        }

        public static void printAsteriskClock(int i_NumOfLines)
        {
            const bool v_isClockDescending = true;

            recursiveAsteriskClockPrinter(i_NumOfLines, 0, i_NumOfLines, v_isClockDescending);
        }

        private static void recursiveAsteriskClockPrinter(int i_NumOfAsterisk, int i_NumOfLine, int i_TargetNumOfLines, bool i_IsClockDescending)
        {
            StringBuilder stringBuilder = new StringBuilder();

            if (i_NumOfLine < 0)
            {
                return;
            }

            if (i_NumOfAsterisk == 1)
            {
                i_IsClockDescending = false;
            }

            stringBuilder.Append(' ', i_NumOfLine).Append('*', i_NumOfAsterisk);
            Console.WriteLine(stringBuilder.ToString());
            if (i_IsClockDescending)
            {
                recursiveAsteriskClockPrinter(i_NumOfAsterisk - 2, i_NumOfLine + 1, i_TargetNumOfLines, i_IsClockDescending);
            }
            else
            {
                recursiveAsteriskClockPrinter(i_NumOfAsterisk + 2, i_NumOfLine - 1, i_TargetNumOfLines, i_IsClockDescending);
            }
        }
    }
}