﻿using System;

namespace Ex01_03
{
    internal class Program
    {
        public static void Main()
        {
            int numOfLines = getUserInput();

            Ex01_02.Program.printAsteriskClock(numOfLines);
        }

        private static int getUserInput()
        {
            string userInput;
            bool isValidInput;

            Console.WriteLine("Please enter the number of lines for the Astrix sand clock (and then press enter):");
            while (true)
            {
                userInput = Console.ReadLine();
                isValidInput = int.TryParse(userInput, out int userInputNum);
                if (isValidInput)
                {
                    if (userInputNum % 2 == 0)
                    {
                        userInputNum++;
                    }

                    return userInputNum;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                }
            }
        }
    }
}
