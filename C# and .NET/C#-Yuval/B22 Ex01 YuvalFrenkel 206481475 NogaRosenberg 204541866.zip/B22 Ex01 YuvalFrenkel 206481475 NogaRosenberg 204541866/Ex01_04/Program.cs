﻿using System;


namespace Ex01_04
{
    internal class Program
    {
        public static void Main()
        {
            string userStringInput = getUserInput();

            printOutput(userStringInput);
        }

        private static string getUserInput()
        {
            string userStringInput;

            Console.WriteLine("Please enter 8 characters string; Please use english letters only or digits only (than press 'enter')");
            while (true)
            {
                userStringInput = Console.ReadLine();
                if (isValidInput(userStringInput))
                {
                    return userStringInput;
                }

                Console.WriteLine("Invalid input. Enter 8 characters string (please use english letters only or digits only)");
            }
        }

        private static void printOutput(string i_StringInput)
        {
            printIsPalindrome(i_StringInput);
            printIsMultiplicationOfThree(i_StringInput);
            printNumOfLowercaseLetters(i_StringInput);
        }

        private static bool isValidInput(string i_StringInput)
        {
            return i_StringInput.Length == 8 && (containsDigitsOnly(i_StringInput) || containsEnglishLettersOnly(i_StringInput));
        }

        private static bool containsEnglishLettersOnly(string i_StringInput)
        {
            foreach (char character in i_StringInput)
            {
                if (!(((character >= 65) && (character <= 90)) || ((character >= 97) && (character <= 122))))
                {
                    return false;
                }
            }

            return true;
        }

        private static bool containsDigitsOnly(string i_StringInput)
        {
            foreach (char character in i_StringInput)
            {
                if (!((character >= 48) && (character <= 57)))
                {
                    return false;
                }
            }

            return true;
        }

        private static bool isPalindrome(string i_StringInput)
        {
            return isPalindromeRecursiveChecker(i_StringInput, 0, (byte)(i_StringInput.Length - 1));
        }

        // $G$ CSS-028 (-5) A method should not include more than one return statement.
        private static bool isPalindromeRecursiveChecker(string i_StringInput, byte i_LeftPointer, byte i_RightPointer)
        {
            if (i_LeftPointer >= i_RightPointer)
            {
                return true;
            }

            if (i_StringInput[i_LeftPointer] != i_StringInput[i_RightPointer])
            {
                return false;
            }

            return isPalindromeRecursiveChecker(i_StringInput, (byte)(i_LeftPointer + 1), (byte)(i_RightPointer - 1));
        }

        private static void printIsPalindrome(string i_StringInput)
        {
            if (isPalindrome(i_StringInput))
            {
                Console.WriteLine("The string is a palindrome");
            }
            else
            {
                Console.WriteLine("The string is not a palindrome");
            }
        }

        private static bool isMultiplictionOfThree(string i_StringInput)
        {
            int number = int.Parse(i_StringInput);

            return number % 3 == 0;
        }

        private static void printIsMultiplicationOfThree(string i_StringInput)
        {
            if (containsDigitsOnly(i_StringInput))
            {
                if (isMultiplictionOfThree(i_StringInput))
                {
                    Console.WriteLine("The number is a multiplication of three");
                }
                else
                {
                    Console.WriteLine("The number is not a multiplication of three");
                }
            }
        }

        private static void printNumOfLowercaseLetters(string i_StringInput)
        {
            if (containsEnglishLettersOnly(i_StringInput))
            {
                Console.WriteLine(string.Format("The number of lowercase letters in the string is {0}", countNumOfLowercaseLetters(i_StringInput)));
            }
        }

        private static byte countNumOfLowercaseLetters(string i_StringInput)
        {
            byte numOfLowercaseLetters = 0;

            foreach (char character in i_StringInput)
            {
                if (character >= 97 && character <= 122)
                {
                    numOfLowercaseLetters++;
                }
            }

            return numOfLowercaseLetters;
        }
    }
}
