﻿namespace Ex04.Menus.Delegates
{
    public delegate void ChooseInvoker();

    public class ActionItem : MenuItem
    {
        public ActionItem(string i_Title)
            : base(i_Title)
        {
        }

        public event ChooseInvoker Chosen;

        internal override void OnChoose()
        {
            if (Chosen != null)
            {
                Chosen.Invoke();
            }
        }
    }
}
