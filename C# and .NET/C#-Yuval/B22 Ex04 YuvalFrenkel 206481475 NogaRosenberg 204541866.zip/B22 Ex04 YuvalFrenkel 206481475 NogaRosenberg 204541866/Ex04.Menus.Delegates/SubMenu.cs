﻿using System;
using System.Collections.Generic;

namespace Ex04.Menus.Delegates
{
    public class SubMenu : MenuItem
    {
        private readonly List<MenuItem> r_SubItems;

        public SubMenu(string i_Title)
            : base(i_Title)
        {
            r_SubItems = new List<MenuItem>();
        }

        public void AddSubItem(MenuItem i_Item)
        {
            i_Item.ParentItem = this;
            r_SubItems.Add(i_Item);
        }

        public void RemoveSubItem(MenuItem i_Item)
        {
            if (r_SubItems.Contains(i_Item))
            {
                r_SubItems.Remove(i_Item);
            }
            else
            {
                throw new ArgumentException("The given item is not a sub-item of this item.");
            }
        }

        internal override void OnChoose()
        {
            showSubItems();
        }

        private void showSubItems()
        {
            int idx = 0;
            string backText = "Back";

            if (IsRoot)
            {
                backText = "Exit";
            }

            Console.Clear();
            Console.WriteLine("**{0}**", Title);
            Console.WriteLine("==============");
            foreach (MenuItem item in r_SubItems)
            {
                idx++;
                Console.WriteLine("{0}. {1}", idx, item.Title);
            }
            Console.WriteLine("0. {0}", backText);
            Console.WriteLine("==============");
            Console.WriteLine("Please enter your choice (1-{0} or 0 to {1})", idx, backText);
            int userChoice = getUserChoice(0, idx);
            if (userChoice == 0)
            {
                goBack();
            }
            else
            {
                MenuItem itemToActivate = r_SubItems[userChoice - 1];
                Console.Clear();
                itemToActivate.OnChoose();
                // $G$ DSN-008 (-10) You should have used polymorphism to implement this.
                if (itemToActivate is ActionItem)
                {
                    showSubItems();
                }
            }
        }

        private void goBack()
        {
            if (!IsRoot)
            {
                ParentItem.OnChoose();
            }
        }

        private int getUserChoice(int i_MinValue, int i_MaxValue)
        {
            int userInputNum;
            string userInput = Console.ReadLine();

            while (!int.TryParse(userInput, out userInputNum) || (userInputNum < i_MinValue || userInputNum > i_MaxValue))
            {
                Console.WriteLine("Invalid input. Please enter an integer in the range {0} to {1}", i_MinValue, i_MaxValue);
                userInput = Console.ReadLine();
            }

            return userInputNum;
        }
    }
}
