﻿namespace Ex04.Menus.Delegates
{
    public class MainMenu
    {
        private SubMenu m_Root;

        public MainMenu(string i_Title)
        {
            m_Root = new SubMenu(i_Title);
        }

        public void Display()
        {
            m_Root.OnChoose();
        }

        public void AddItem(MenuItem i_Item)
        {
            m_Root.AddSubItem(i_Item);
        }
    }

}