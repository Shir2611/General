﻿using System;
using System.Collections.Generic;

namespace Ex04.Menus.Interfaces
{
    public abstract class MenuItem
    {
        public MenuItem(string i_Title)
        {
            Title = i_Title;
        }

        public string Title { get; private set; }

        internal MenuItem ParentItem { get; set; }

        protected bool IsRoot
        {
            get { return ParentItem == null; }
        }

        internal abstract void OnChoose();
    }
}
