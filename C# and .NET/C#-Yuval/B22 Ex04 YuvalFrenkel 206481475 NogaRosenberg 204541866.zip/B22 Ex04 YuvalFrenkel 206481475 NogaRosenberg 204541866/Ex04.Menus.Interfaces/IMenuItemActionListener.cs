﻿namespace Ex04.Menus.Interfaces
{
    public interface IMenuItemActionListener
    {
        void Activate();
    }
}
