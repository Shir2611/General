﻿namespace Ex04.Menus.Interfaces
{
    public class MainMenu
    {
        private SubMenu m_Root;

        public MainMenu(string i_Title)
        {
            m_Root = new SubMenu(i_Title);
        }

        public void AddItem(MenuItem i_Item)
        {
            m_Root.AddSubItem(i_Item);
        }

        public void Display()
        {
            m_Root.OnChoose();
        }
    }

}