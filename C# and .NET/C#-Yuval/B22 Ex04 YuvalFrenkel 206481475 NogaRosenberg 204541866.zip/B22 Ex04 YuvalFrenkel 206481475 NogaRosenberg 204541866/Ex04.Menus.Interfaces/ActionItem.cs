﻿namespace Ex04.Menus.Interfaces
{
    public class ActionItem : MenuItem
    {
        public ActionItem(string i_Title)
            : base(i_Title)
        {
        }

        public IMenuItemActionListener ActionListener { get; set; }

        internal override void OnChoose()
        {
            if (ActionListener != null)
            {
                ActionListener.Activate();
            }
        }
    }
}
