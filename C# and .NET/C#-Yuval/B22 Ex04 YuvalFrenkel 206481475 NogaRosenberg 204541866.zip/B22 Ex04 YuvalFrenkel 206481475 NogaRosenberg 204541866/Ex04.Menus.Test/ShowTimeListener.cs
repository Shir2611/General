﻿using System;
using Ex04.Menus.Interfaces;

namespace Ex04.Menus.Test
{
    internal class ShowTimeListener : IMenuItemActionListener
    {
        public void Activate()
        {
            Console.WriteLine(DateTime.Now.ToShortTimeString());
            Console.Write("Press Enter to continue...");
            Console.ReadLine();
        }
    }
}
