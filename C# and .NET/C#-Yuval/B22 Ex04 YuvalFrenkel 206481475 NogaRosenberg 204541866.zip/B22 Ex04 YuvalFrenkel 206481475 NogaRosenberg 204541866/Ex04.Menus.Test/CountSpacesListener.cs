﻿using System;
using Ex04.Menus.Interfaces;

namespace Ex04.Menus.Test
{
    internal class CountSpacesListener : IMenuItemActionListener
    {
        public void Activate()
        {
            Console.WriteLine("Please enter a sentence then press Enter");
            string userInput = Console.ReadLine();
            int numOfSpaces = 0;
            foreach (char c in userInput)
            {
                if (c == ' ')
                {
                    numOfSpaces++;
                }
            }

            Console.WriteLine("Number of spaces in the sentence is {0}.", numOfSpaces);
            Console.Write("Press Enter to continue...");
            Console.ReadLine();
        }
    }
}
