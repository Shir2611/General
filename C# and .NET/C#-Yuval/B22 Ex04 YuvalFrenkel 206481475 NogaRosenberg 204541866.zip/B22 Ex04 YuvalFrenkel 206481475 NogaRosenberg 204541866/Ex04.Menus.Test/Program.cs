﻿using System;

namespace Ex04.Menus.Test
{
    public class Program
    {
        public static void Main()
        {
            // Main menu implementation with interfaces
            Interfaces.MainMenu interfacesMenu = new Interfaces.MainMenu("Interfaces Main Menu");

            Interfaces.SubMenu interfacesShowDateTimeItem = new Interfaces.SubMenu("Show Date/Time");

            Interfaces.ActionItem interfacesShowTimeItem = new Interfaces.ActionItem("Show Time");
            interfacesShowTimeItem.ActionListener = new ShowTimeListener();
            Interfaces.ActionItem interfacesShowDateItem = new Interfaces.ActionItem("Show Date");
            interfacesShowDateItem.ActionListener = new ShowDateListener();

            interfacesShowDateTimeItem.AddSubItem(interfacesShowTimeItem);
            interfacesShowDateTimeItem.AddSubItem(interfacesShowDateItem);
            interfacesMenu.AddItem(interfacesShowDateTimeItem);

            Interfaces.SubMenu interfacesVersionAndSpacesItem = new Interfaces.SubMenu("Version and Spaces");

            Interfaces.ActionItem interfacesCountSpacesItem = new Interfaces.ActionItem("Count Spaces");
            interfacesCountSpacesItem.ActionListener = new CountSpacesListener();
            Interfaces.ActionItem interfacesShowVersionItem = new Interfaces.ActionItem("Show Version");
            interfacesShowVersionItem.ActionListener = new ShowVersionListener();

            interfacesVersionAndSpacesItem.AddSubItem(interfacesCountSpacesItem);
            interfacesVersionAndSpacesItem.AddSubItem(interfacesShowVersionItem);
            interfacesMenu.AddItem(interfacesVersionAndSpacesItem);

            interfacesMenu.Display();

            // Main menu implementation with delegates
            Delegates.MainMenu delegatesMenu = new Delegates.MainMenu("Delegates Main Menu");

            Delegates.SubMenu delegatesShowDateTimeItem = new Delegates.SubMenu("Show Date/Time");

            Delegates.ActionItem delegatesShowTimeItem = new Delegates.ActionItem("Show Time");
            delegatesShowTimeItem.Chosen += delegatesShowTimeItem_Chosen;
            Delegates.ActionItem delegatesShowDateItem = new Delegates.ActionItem("Show Date");
            delegatesShowDateItem.Chosen += delegatesShowDateItem_Chosen;

            delegatesShowDateTimeItem.AddSubItem(delegatesShowTimeItem);
            delegatesShowDateTimeItem.AddSubItem(delegatesShowDateItem);
            delegatesMenu.AddItem(delegatesShowDateTimeItem);

            Delegates.SubMenu delegatesVersionAndSpacesItem = new Delegates.SubMenu("Version and Spaces");

            Delegates.ActionItem delegatesCountSpacesItem = new Delegates.ActionItem("Count Spaces");
            delegatesCountSpacesItem.Chosen += delegatesCountSpacesItem_Chosen;
            Delegates.ActionItem delegatesShowVersionItem = new Delegates.ActionItem("Show Version");
            delegatesShowVersionItem.Chosen += delegatesShowVersionItem_Chosen;

            delegatesVersionAndSpacesItem.AddSubItem(delegatesCountSpacesItem);
            delegatesVersionAndSpacesItem.AddSubItem(delegatesShowVersionItem);
            delegatesMenu.AddItem(delegatesVersionAndSpacesItem);

            delegatesMenu.Display();
        }

        private static void delegatesShowTimeItem_Chosen()
        {
            Console.WriteLine(DateTime.Now.ToShortTimeString());
            Console.Write("Press Enter to continue...");
            Console.ReadLine();
        }

        private static void delegatesShowDateItem_Chosen()
        {
            Console.WriteLine(DateTime.Now.Date.ToShortDateString());
            Console.Write("Press Enter to continue...");
            Console.ReadLine();
        }

        private static void delegatesCountSpacesItem_Chosen()
        {
            Console.WriteLine("Please enter a sentence then press Enter");
            string userInput = Console.ReadLine();
            int numOfSpaces = 0;
            foreach (char c in userInput)
            {
                if (c == ' ')
                {
                    numOfSpaces++;
                }
            }

            Console.WriteLine("Number of spaces in the sentence is {0}.", numOfSpaces);
            Console.Write("Press Enter to continue...");
            Console.ReadLine();
        }

        private static void delegatesShowVersionItem_Chosen()
        {
            Console.WriteLine("Version: 22.2.4.8950");
            Console.Write("Press Enter to continue...");
            Console.ReadLine();
        }
    }
}
