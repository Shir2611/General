﻿using System;
using Ex04.Menus.Interfaces;

namespace Ex04.Menus.Test
{
    internal class ShowVersionListener : IMenuItemActionListener
    {
        public void Activate()
        {
            Console.WriteLine("Version: 22.2.4.8950");
            Console.Write("Press Enter to continue...");
            Console.ReadLine();
        }
    }
}
