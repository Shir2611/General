﻿using System;
using Ex04.Menus.Interfaces;

namespace Ex04.Menus.Test
{
    internal class ShowDateListener : IMenuItemActionListener
    {
        public void Activate()
        {
            Console.WriteLine(DateTime.Now.Date.ToShortDateString());
            Console.Write("Press Enter to continue...");
            Console.ReadLine();
        }
    }
}
