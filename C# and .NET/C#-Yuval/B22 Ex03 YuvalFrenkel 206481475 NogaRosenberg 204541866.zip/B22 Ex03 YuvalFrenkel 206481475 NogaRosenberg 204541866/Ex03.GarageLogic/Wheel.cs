﻿namespace Ex03.GarageLogic
{
    public class Wheel
    {
        public Wheel(string i_Manufacturer, float i_CurrentAirPressure, float i_RecommendedMaximalAirPressure)
        {
            Manufacturer = i_Manufacturer;
            CurrentAirPressure = i_CurrentAirPressure;
            RecommendedMaximalAirPressure = i_RecommendedMaximalAirPressure;
        }

        public string Manufacturer { get; }

        public float CurrentAirPressure { get; private set; }

        public float RecommendedMaximalAirPressure { get; }

        public void AddAir(float i_AmountOfAirToAdd)
        {
            if (CurrentAirPressure + i_AmountOfAirToAdd > RecommendedMaximalAirPressure)
            {
                throw new ValueOutOfRangeException(0, RecommendedMaximalAirPressure);
            }
            else
            {
                CurrentAirPressure += i_AmountOfAirToAdd;
            }
        }
    }
}
