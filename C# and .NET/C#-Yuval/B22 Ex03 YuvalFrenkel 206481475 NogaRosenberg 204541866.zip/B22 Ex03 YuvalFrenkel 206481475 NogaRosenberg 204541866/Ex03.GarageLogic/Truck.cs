﻿using System;

namespace Ex03.GarageLogic
{
    internal class Truck : Vehicle
    {
        internal Truck()
        {
            MaxFuelAmount = 120f;
            MaxChargeAmount = 0f;
            MaxWheelsPressure = 24f;
            NumOfWheels = 16;
            FuelType = FuelBasedEngine.eFuelType.Soler;
            NumOfExtraDetails = 2;
        }

        private enum eProperties
        {
            ColdStorage = 1,
            TrunkVolume,
        }

        public override VehicleCreator.eVehicleType Type
        {
            get
            {
                return VehicleCreator.eVehicleType.Truck;
            }

            protected set
            {
                Type = value;
            }
        }

        private bool ColdStorage { get; set; }

        private float TrunkVolume { get; set; }

        public override string GetExtraDetailDescription(int i_ExtraDetailNum)
        {
            string detailDescription;

            switch (i_ExtraDetailNum)
            {
                case (int)eProperties.ColdStorage:

                    detailDescription = "Can load cold storage (True / False)";
                    break;

                case (int)eProperties.TrunkVolume:

                    detailDescription = "Trunk volume (Float)";
                    break;

                default:

                    throw new ArgumentException("Invalid extra detail identifier given.");
            }

            return detailDescription;
        }

        public override void SetExtraDetail(int i_ExtraDetailNum, string i_ExtraDetailValue)
        {
            switch (i_ExtraDetailNum)
            {
                case (int)eProperties.ColdStorage:

                    bool coldStorageInput;
                    if (bool.TryParse(i_ExtraDetailValue, out coldStorageInput))
                    {
                        ColdStorage = coldStorageInput;
                    }
                    else
                    {
                        throw new ArgumentException("Invalid boolean value given.");
                    }

                    break;

                case (int)eProperties.TrunkVolume:

                    float trunkVolumeInput;
                    if (float.TryParse(i_ExtraDetailValue, out trunkVolumeInput) && trunkVolumeInput > 0)
                    {
                        TrunkVolume = trunkVolumeInput;
                    }
                    else
                    {
                        throw new ArgumentException("Invalid trunk volume given.");
                    }

                    break;

                default:

                    throw new ArgumentException("Invalid extra detail identifier given.");
            }
        }

        public override string ExtraDetailsToString()
        {
            return string.Format(
@"Can load cold storage: {0}
Trunk volume: {1}",
ColdStorage,
TrunkVolume);
        }
    }
}
