﻿namespace Ex03.GarageLogic
{
    public class ElectricEngine : Engine
    {
        public ElectricEngine(float i_MaxAmountOfEnergy)
            : base(i_MaxAmountOfEnergy)
        {
        }

        public void Recharge(float i_MinutesToAdd)
        {
            float hoursToAdd = i_MinutesToAdd / 60;
            AddEnergy(hoursToAdd);
        }
    }
}