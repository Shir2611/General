﻿using System.Collections.Generic;

namespace Ex03.GarageLogic
{
    public abstract class Vehicle
    {
        public float MaxFuelAmount { get; protected set; }

        public float MaxChargeAmount { get; protected set; }

        public float MaxWheelsPressure { get; protected set; }

        public int NumOfWheels { get; protected set; }

        public int NumOfExtraDetails { get; protected set; }

        public abstract VehicleCreator.eVehicleType Type { get; protected set; }

        public FuelBasedEngine.eFuelType FuelType { get; protected set; }

        public Engine VehicleEngine { get; set; }

        public string LicenseNumber { get; set; }

        public string ModelName { get; set; }

        public List<Wheel> Wheels { get; set; }

        public override string ToString()
        {
            string vehicleInformation = string.Format(
@"
License number: {0}
Model name: {1}
{2}
Wheels manufacturer: {3}
Wheels air pressure: {4}
{5}",
LicenseNumber,
ModelName,
VehicleEngine.ToString(),
Wheels[0].Manufacturer,
Wheels[0].CurrentAirPressure,
ExtraDetailsToString());

            return vehicleInformation;
        }

        public abstract string GetExtraDetailDescription(int i_ExtraDetailNum);

        public abstract void SetExtraDetail(int i_ExtraDetailNum, string i_ExtraDetailValue);

        public abstract string ExtraDetailsToString();
    }
}
