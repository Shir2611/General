﻿using System;

namespace Ex03.GarageLogic
{
    public class FuelBasedEngine : Engine
    {
        public FuelBasedEngine(float i_MaxAmountOfEnergy, eFuelType i_FuelType)
            : base(i_MaxAmountOfEnergy)
        {
            FuelType = i_FuelType;
        }

        public enum eFuelType
        {
            Soler = 1,
            Octan95,
            Octan96,
            Octan98,
        }

        public eFuelType FuelType { get; }

        public void Refuel(eFuelType i_FuelType, float i_FuelToAdd)
        {
            if(FuelType != i_FuelType)
            {
                throw new ArgumentException("Wrong or invalid fuel type!");
            }
            else
            {
                AddEnergy(i_FuelToAdd);
            }
        }
        
        public override string ToString()
        {
            return string.Format("{0}\nFuel type: {1}", base.ToString(), FuelType.ToString());
        }
    }
}