﻿namespace Ex03.GarageLogic
{
    public abstract class Engine
    {
        public Engine(float i_MaxAmountOfEnergy)
        {
            MaxAmountOfEnergy = i_MaxAmountOfEnergy;
        }

        public enum eType
        {
            Electric = 1,
            Fuel,
        }

        public eType Type { get; set; }

        public float EngineEnergyPercentage
        {
            get
            {
                return AmountOfEnergyLeft / MaxAmountOfEnergy;
            }
        }

        public float AmountOfEnergyLeft { get; set; }

        public float MaxAmountOfEnergy { get; }

        public override string ToString()
        {
            return string.Format("Energy left: {0}%", EngineEnergyPercentage);
        }

        protected void AddEnergy(float i_AmountOfEnergyToAdd)
        {
            float newAmountOfEnergy = AmountOfEnergyLeft + i_AmountOfEnergyToAdd;
            if (newAmountOfEnergy > MaxAmountOfEnergy || newAmountOfEnergy < 0)
            {
                throw new ValueOutOfRangeException(0, MaxAmountOfEnergy);
            }

            AmountOfEnergyLeft += i_AmountOfEnergyToAdd;
        }
    }
}