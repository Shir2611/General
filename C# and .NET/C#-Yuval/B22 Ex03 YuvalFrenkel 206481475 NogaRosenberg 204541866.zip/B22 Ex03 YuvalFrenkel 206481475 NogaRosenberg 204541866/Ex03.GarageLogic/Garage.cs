﻿using System;
using System.Collections.Generic;

namespace Ex03.GarageLogic
{
    public class Garage
    {
        private readonly Dictionary<string, Vehicle> r_Vehicles = new Dictionary<string, Vehicle>();

        private readonly Dictionary<Vehicle, ClientInfo> r_ClientInfo = new Dictionary<Vehicle, ClientInfo>();

        public VehicleCreator Creator { get; } = new VehicleCreator();

        public void RefuelVehicle(string i_LicenseNumber, int i_FuelType, float i_AmountOfFuel)
        {
            Vehicle vehicle;

            if (!IsLicenseNumberInGarage(i_LicenseNumber))
            {
                throw new ArgumentException("No vehicle with this license number was found in the garage.");
            }

            vehicle = r_Vehicles[i_LicenseNumber];
            if (!(vehicle.VehicleEngine is FuelBasedEngine))
            {
                throw new ArgumentException("This vehicle is not fuel based.");
            }

            (vehicle.VehicleEngine as FuelBasedEngine).Refuel((FuelBasedEngine.eFuelType)i_FuelType, i_AmountOfFuel);
        }

        public void ChargeVehicle(string i_LicenseNumber, float i_NumberOfMinutesToCharge)
        {
            Vehicle vehicle;

            if (!IsLicenseNumberInGarage(i_LicenseNumber))
            {
                throw new ArgumentException("No vehicle with this license number was found in the garage.");
            }

            vehicle = r_Vehicles[i_LicenseNumber];
            if (!(vehicle.VehicleEngine is ElectricEngine))
            {
                throw new ArgumentException("This vehicle is not electric.");
            }

            (vehicle.VehicleEngine as ElectricEngine).Recharge(i_NumberOfMinutesToCharge);
        }
        // $G$ CSS-999 (-3) Missing blank line before return method.
        public string VehicleInfoToString(string i_LicenseNumber)
        {
            Vehicle vehicle;
            ClientInfo clientInfo;

            if (!IsLicenseNumberInGarage(i_LicenseNumber))
            {
                throw new ArgumentException("No vehicle with this license number was found in the garage.");
            }

            vehicle = r_Vehicles[i_LicenseNumber];
            clientInfo = r_ClientInfo[vehicle];
            return string.Format("Client name: {0}\nVehicle state: {1}\n{2}", clientInfo.Name, clientInfo.VehicleState, vehicle.ToString());
        }

        public void InflateWheelsToMax(string i_LicenseNumber)
        {
            Vehicle vehicle;

            if (!IsLicenseNumberInGarage(i_LicenseNumber))
            {
                throw new ArgumentException("No vehicle with this license number was found in the garage.");
            }

            vehicle = r_Vehicles[i_LicenseNumber];
            foreach (Wheel wheel in vehicle.Wheels)
            {
                float airToAdd = wheel.RecommendedMaximalAirPressure - wheel.CurrentAirPressure;
                wheel.AddAir(airToAdd);
            }
        }

        public string[] GetPossibleVehicleTypes()
        {
            return Enum.GetNames(typeof(VehicleCreator.eVehicleType));
        }

        public List<string> GetCurrentLicenseNumbersInGarageByState(int i_State)
        {
            List<string> licenseNumbersList = new List<string>();
            foreach (string licenseNumber in r_Vehicles.Keys)
            {
                Vehicle vehicle = r_Vehicles[licenseNumber];
                if ((int)r_ClientInfo[vehicle].VehicleState == i_State || i_State == -1)
                {
                    licenseNumbersList.Add(licenseNumber);
                }
            }

            return licenseNumbersList;
        }

        public bool IsLicenseNumberInGarage(string i_LicenseNumber)
        {
            return r_Vehicles.ContainsKey(i_LicenseNumber);
        }

        public void ChangeVehicleState(string i_LicenseNumber, int i_State)
        {
            Vehicle vehicle;

            if (!IsLicenseNumberInGarage(i_LicenseNumber))
            {
                throw new ArgumentException("No vehicle with this license number was found in the garage.");
            }

            vehicle = r_Vehicles[i_LicenseNumber];
            r_ClientInfo[vehicle].VehicleState = (ClientInfo.eVehicleState)i_State;
        }

        public void AddVehicle(Vehicle i_Vehicle, ClientInfo i_ClientInfo)
        {
            r_Vehicles.Add(i_Vehicle.LicenseNumber, i_Vehicle);
            r_ClientInfo.Add(i_Vehicle, i_ClientInfo);
        }

        public Vehicle GetVehicleByLicenseNumber(string i_LicenseNumber)
        {
            if (!IsLicenseNumberInGarage(i_LicenseNumber))
            {
                throw new ArgumentException("No vehicle with this license number was found in the garage.");
            }

            return r_Vehicles[i_LicenseNumber];
        }
    }
}
