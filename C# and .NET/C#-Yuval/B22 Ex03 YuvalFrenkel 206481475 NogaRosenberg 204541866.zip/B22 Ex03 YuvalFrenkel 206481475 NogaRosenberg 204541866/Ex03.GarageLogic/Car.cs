﻿using System;

namespace Ex03.GarageLogic
{
    public class Car : Vehicle
    {
        public Car()
        {
            MaxFuelAmount = 38f;
            MaxChargeAmount = 3.3f;
            MaxWheelsPressure = 29f;
            NumOfWheels = 4;
            FuelType = FuelBasedEngine.eFuelType.Octan95;
            NumOfExtraDetails = 2;
        }

        private enum eProperties
        {
            Color = 1,
            NumberOfDoors,
        }

        private enum eColor
        {
            Red = 1,
            White,
            Green,
            Blue,
        }

        public override VehicleCreator.eVehicleType Type
        {
            get
            {
                VehicleCreator.eVehicleType vehicleType;

                if (VehicleEngine.Type == Engine.eType.Fuel)
                {
                    vehicleType = VehicleCreator.eVehicleType.ElectricCar;
                }
                else
                {
                    vehicleType = VehicleCreator.eVehicleType.FuelBasedCar;
                }

                return vehicleType;
            }

            protected set
            {
                Type = value;
            }
        }

        public override string GetExtraDetailDescription(int i_ExtraDetailNum)
        {
            string detailDescription;

            switch (i_ExtraDetailNum)
            {
                case (int)eProperties.Color:

                    detailDescription = "Car color (Red, White, Green or Blue)";
                    break;

                case (int)eProperties.NumberOfDoors:

                    detailDescription = "Number of doors (2, 3, 4 or 5)";
                    break;

                default:

                    throw new ArgumentException("Invalid extra detail identifier given.");
            }

            return detailDescription;
        }

        public override void SetExtraDetail(int i_ExtraDetailNum, string i_ExtraDetailValue)
        {
            switch (i_ExtraDetailNum)
            {
                case (int)eProperties.Color:

                    eColor colorInput;
                    if (tryParseToColor(i_ExtraDetailValue, out colorInput))
                    {
                        Color = colorInput;
                    }
                    else
                    {
                        throw new ArgumentException("Invalid car color given.");
                    }

                    break;

                case (int)eProperties.NumberOfDoors:

                    int numOfDoorsInput;
                    if (int.TryParse(i_ExtraDetailValue, out numOfDoorsInput) && numOfDoorsInput >= 2 && numOfDoorsInput <= 5)
                    {
                        NumberOfDoors = numOfDoorsInput;
                    }
                    else
                    {
                        throw new ArgumentException("Invalid number of doors given.");
                    }

                    break;

                default:

                    throw new ArgumentException("Invalid extra detail identifier given.");
            }
        }

        public override string ExtraDetailsToString()
        {
            return string.Format(
@"Car color: {0}
Number of doors: {1}",
Color,
NumberOfDoors);
        }

        private eColor Color { get; set; }

        private int NumberOfDoors { get; set; }

        private bool tryParseToColor(string i_Value, out eColor o_OutputBox)
        {
            o_OutputBox = eColor.Red;
            bool isValid = true;

            switch (i_Value)
            {
                case "Red":

                    o_OutputBox = eColor.Red;
                    break;

                case "White":

                    o_OutputBox = eColor.White;
                    break;

                case "Green":

                    o_OutputBox = eColor.Green;
                    break;

                case "Blue":

                    o_OutputBox = eColor.Blue;
                    break;

                default:

                    isValid = false;
                    break;
            }

            return isValid;
        }
    }
}
