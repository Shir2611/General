﻿using System.Collections.Generic;

namespace Ex03.GarageLogic
{
    public class VehicleCreator
    {
        public enum eVehicleType
        {
            FuelBasedCar = 1,
            FuelBasedMotorcycle,
            ElectricCar,
            ElectricMotorcycle,
            Truck,
        }

        public Vehicle CreateVehicle(eVehicleType i_VehicleType)
        {
            Vehicle newVehicle = null;
            // $G$ CSS-018 (-5) You should have use enum here for user choice.
            if (i_VehicleType == eVehicleType.FuelBasedCar)
            {
                newVehicle = new Car();
                newVehicle.VehicleEngine = new FuelBasedEngine(newVehicle.MaxFuelAmount, newVehicle.FuelType);
            }
            else if (i_VehicleType == eVehicleType.ElectricCar)
            {
                newVehicle = new Car();
                newVehicle.VehicleEngine = new ElectricEngine(newVehicle.MaxChargeAmount);
            }
            else if (i_VehicleType == eVehicleType.FuelBasedMotorcycle)
            {
                newVehicle = new Motorcycle();
                newVehicle.VehicleEngine = new FuelBasedEngine(newVehicle.MaxFuelAmount, newVehicle.FuelType);
            }
            else if (i_VehicleType == eVehicleType.ElectricMotorcycle)
            {
                newVehicle = new Motorcycle();
                newVehicle.VehicleEngine = new ElectricEngine(newVehicle.MaxChargeAmount);
            }
            else if (i_VehicleType == eVehicleType.Truck)
            {
                newVehicle = new Truck();
                newVehicle.VehicleEngine = new FuelBasedEngine(newVehicle.MaxFuelAmount, newVehicle.FuelType);
            }

            return newVehicle;
        }
        // $G$ CSS-999 (-4) Missing blank line after local variable declarations.
        public List<Wheel> CreateWheels(int i_NumOfWheels, string i_Manufacturer, float i_CurrentAirPressure, float i_RecommendedMaximalAirPressure)
        {
            List<Wheel> wheelsList = new List<Wheel>();
            for (int i = 0; i < i_NumOfWheels; i++)
            {
                wheelsList.Add(new Wheel(i_Manufacturer, i_CurrentAirPressure, i_RecommendedMaximalAirPressure));
            }

            return wheelsList;
        }
    }
}
