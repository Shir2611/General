﻿namespace Ex03.GarageLogic
{
    public class ClientInfo
    {
        public ClientInfo(string i_Name, string i_PhoneNumber)
        {
            Name = i_Name;
            PhoneNumber = i_PhoneNumber;
        }

        public enum eVehicleState
        {
            InRepairing = 1,
            Repaired,
            Paid,
        }

        public string Name { get; }

        public string PhoneNumber { get; }

        public eVehicleState VehicleState { get; set; } = eVehicleState.InRepairing;
    }
}
