﻿using System;

namespace Ex03.GarageLogic
{
    internal class Motorcycle : Vehicle
    {
        internal Motorcycle()
        {
            MaxFuelAmount = 6.2f;
            MaxChargeAmount = 2.5f;
            MaxWheelsPressure = 31f;
            NumOfWheels = 2;
            FuelType = FuelBasedEngine.eFuelType.Octan98;
            NumOfExtraDetails = 2;
        }

        private enum eProperties
        {
            LicenseType = 1,
            EngineVolume,
        }

        public override VehicleCreator.eVehicleType Type
        {
            get
            {
                VehicleCreator.eVehicleType vehicleType;

                if (VehicleEngine.Type == Engine.eType.Fuel)
                {
                    vehicleType = VehicleCreator.eVehicleType.ElectricMotorcycle;
                }
                else
                {
                    vehicleType = VehicleCreator.eVehicleType.FuelBasedMotorcycle;
                }

                return vehicleType;
            }

            protected set
            {
                Type = value;
            }
        }

        private int EngineVolume { get; set; }

        private string LicenseType { get; set; }

        public override string GetExtraDetailDescription(int i_ExtraDetailNum)
        {
            string detailDescription;

            switch (i_ExtraDetailNum)
            {

                // $G$ CSS-999 (-4) Missing brackets between cases.
                case (int)eProperties.LicenseType:

                    detailDescription = "License type (A, A1, B1 or BB)";
                    break;

                case (int)eProperties.EngineVolume:

                    detailDescription = "Engine volume (Integer)";
                    break;

                default:

                    throw new ArgumentException("Invalid extra detail identifier given.");
            }

            return detailDescription;
        }

        public override void SetExtraDetail(int i_ExtraDetailNum, string i_ExtraDetailValue)
        {
            switch (i_ExtraDetailNum)
            {
                case (int)eProperties.LicenseType:

                    if (isValidLicenseType(i_ExtraDetailValue))
                    {
                        LicenseType = i_ExtraDetailValue;
                    }
                    else
                    {
                        throw new ArgumentException("Invalid license type given.");
                    }

                    break;

                case (int)eProperties.EngineVolume:

                    int engineVolumeInput;
                    if (int.TryParse(i_ExtraDetailValue, out engineVolumeInput) && engineVolumeInput > 0)
                    {
                        EngineVolume = engineVolumeInput;
                    }
                    else
                    {
                        throw new ArgumentException("Invalid engine volume given.");
                    }

                    break;

                default:

                    throw new ArgumentException("Invalid extra detail identifier given.");
            }
        }

        public override string ExtraDetailsToString()
        {
            return string.Format(
@"License type: {0}
Engine volume: {1}",
LicenseType,
EngineVolume);
        }

        private bool isValidLicenseType(string i_InputLicenseType)
        {
            return i_InputLicenseType == "A" || i_InputLicenseType == "A1" || i_InputLicenseType == "B1" || i_InputLicenseType == "BB";
        }
    }
}
