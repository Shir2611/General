﻿using System;
using System.Collections.Generic;
using System.Text;
using Ex03.GarageLogic;

namespace Ex03.ConsoleUI
{
    internal class UserInterface
    {
        private static readonly Garage sr_Garage = new Garage();
        private static readonly int sr_MinInputValue = 1;

        private enum eUserActions
        {
            InsertVehicle = 1,
            DisplayLicenseNumbers,
            ChangeVehicleState,
            InflateWheelsToMax,
            RefuelVehicle,
            ChargeVehicle,
            DisplayVehicleInfo,
            Exit,
        }

        internal void ManageGarage()
        {
            bool isExit = false;

            Console.WriteLine("Welcome to the garage.");

            while (!isExit)
            {
                switch (printMenuAndGetUserChoice())
                {
                    case eUserActions.InsertVehicle:

                        insertVehicle();
                        break;

                    case eUserActions.DisplayLicenseNumbers:

                        currentLicenseNumbersInGarage();
                        break;

                    case eUserActions.ChangeVehicleState:

                        changeStatusOfVehicle();
                        break;
                    case eUserActions.InflateWheelsToMax:

                        inflateWheelsToMax();
                        break;

                    case eUserActions.RefuelVehicle:

                        refuelVehicle();
                        break;

                    case eUserActions.ChargeVehicle:

                        chargeVehicle();
                        break;

                    case eUserActions.DisplayVehicleInfo:

                        displayVehicleInfo();
                        break;

                    case eUserActions.Exit:

                        isExit = true;
                        break;
                }
                Console.Clear();
            }
        }

        private void insertVehicle()
        {
            Console.WriteLine("Hello. Please enter the license number of the required vehicle:");
            string licenseNumber = getNonEmptyInput();

            if (sr_Garage.IsLicenseNumberInGarage(licenseNumber))
            {
                int changeStatus = 1;
                int cancelOption = 2;
                int inputNumber = receiveValidIntInRange(changeStatus, cancelOption, string.Format(@"Vehicle with license number '{0}' is of type {1}.
Please choose an option:
  1) Change the state of this vehicle
  2) Cancel", licenseNumber, sr_Garage.GetVehicleByLicenseNumber(licenseNumber).LicenseNumber));

                if (inputNumber == changeStatus)
                {
                    sr_Garage.ChangeVehicleState(licenseNumber, (int)ClientInfo.eVehicleState.InRepairing);
                }
            }
            else
            {
                int inputTypeOfVehicleNumber = getTypeOfVehicleNumber();
                Vehicle newVehicle = sr_Garage.Creator.CreateVehicle((VehicleCreator.eVehicleType)inputTypeOfVehicleNumber);
                newVehicle.LicenseNumber = licenseNumber;
                string modelName = getNonEmptyInput("Please enter the model name of the vehicle:");
                newVehicle.ModelName = modelName;
                string wheelsManufacturer = getNonEmptyInput("Please enter the name of the wheels manufacturer:");
                float wheelsCurrentAirPressure = receiveValidFloatInRange(0, newVehicle.MaxWheelsPressure, "Please enter the wheels current air pressure:");
                List<Wheel> wheelsList = sr_Garage.Creator.CreateWheels(newVehicle.NumOfWheels, wheelsManufacturer, wheelsCurrentAirPressure, newVehicle.MaxWheelsPressure);
                newVehicle.Wheels = wheelsList;
                float currentEnergyLeft = receiveValidFloatInRange(0, newVehicle.VehicleEngine.MaxAmountOfEnergy, "Please enter the amount of fuel / charging hours left in the vehicle:");
                newVehicle.VehicleEngine.AmountOfEnergyLeft = currentEnergyLeft;
                
                for (int i = 1; i <= newVehicle.NumOfExtraDetails; i++)
                {
                    assignDetailValue(i, newVehicle);
                }

                string clientName = getNonEmptyInput("Please enter your name:");
                string clientPhoneNumber = getOnlyDigitsString("Please enter your phone number:");
                ClientInfo clientInfo = new ClientInfo(clientName, clientPhoneNumber);

                sr_Garage.AddVehicle(newVehicle, clientInfo);
            }
        }

        private void assignDetailValue(int i_ExtraDetailNum, Vehicle i_Vehicle)
        {
            try
            {
                string message = string.Format("Please enter the following extra detail - {0}:", i_Vehicle.GetExtraDetailDescription(i_ExtraDetailNum));
                string detailValueInput = getNonEmptyInput(message);
                i_Vehicle.SetExtraDetail(i_ExtraDetailNum, detailValueInput);
            }
            catch (ArgumentException argException)
            {
                Console.WriteLine(argException.Message);
                assignDetailValue(i_ExtraDetailNum, i_Vehicle);
            }
        }

        private string getOnlyDigitsString()
        {
            string input = getNonEmptyInput();

            while (!isOnlyDigitsString(input))
            {
                Console.WriteLine("Input shuld contain only digits, please try again:");
                input = getNonEmptyInput();
            }

            return input;
        }
        // $G$ CSS-999 (-5) Missing blank line before return method.
        private string getOnlyDigitsString(string i_Message)
        {
            Console.WriteLine(i_Message);
            return getOnlyDigitsString();
        }

        private bool isOnlyDigitsString(string i_String)
        {
            bool isOnlyDigits = true;

            foreach (char character in i_String)
            {
                if (character < '0' || character > '9')
                {
                    isOnlyDigits = false;
                }
            }

            return isOnlyDigits;
        }
        // $G$ CSS-999 (-3) Missing blank line after local variable declarations.
        private int getTypeOfVehicleNumber()
        {
            StringBuilder messageToPrint = new StringBuilder();
            int index = 1;
            Console.WriteLine("Please choose a vehicle type:");
            foreach (VehicleCreator.eVehicleType currentType in Enum.GetValues(typeof(VehicleCreator.eVehicleType)))
            {
                messageToPrint.Append(string.Format(@"  {0}) {1}{2}", index, convertCamelCaseStringToSpaced(currentType.ToString()), Environment.NewLine));
                index++;
            }

            Console.WriteLine(messageToPrint);

            int minInputValue = 1;
            int maxInputValue = Enum.GetValues(typeof(VehicleCreator.eVehicleType)).Length;

            return receiveValidIntInRange(minInputValue, maxInputValue);
        }

        private string convertCamelCaseStringToSpaced(string i_CamelCasedString)
        {
            string spacedString = i_CamelCasedString[0].ToString();
            for (int i = 1; i < i_CamelCasedString.Length; i++)
            {
                if (i_CamelCasedString[i] < 'a')
                {
                    spacedString += string.Format(" {0}", i_CamelCasedString[i]);
                }
                else
                {
                    spacedString += string.Format("{0}", i_CamelCasedString[i]);
                }
            }
            return spacedString;
        }

        private eUserActions printMenuAndGetUserChoice()
        {
            int maxInputValue = 8;

            string message = string.Format(@"The options are:
1) Insert a vehicle
2) Display list of all licences numbers currently in the garage
3) Change vehicle state
4) Inflate wheels to maximum
5) Refuel vehicle (For fuel based vehicles)
6) Charge vehicle (For electric vehicles)
7) Display vehicle info
8) Exit
    
Please choose an option: ({0} to {1})", sr_MinInputValue, maxInputValue);

            int messageNumber = receiveValidIntInRange(sr_MinInputValue, maxInputValue, message);
            Console.Clear();
            return (eUserActions)messageNumber;
        }

        private void currentLicenseNumbersInGarage()
        {
            string message = @"How would you like to filter the results:
1) Being repaired
2) Repair is done
3) Paid
4) No filter

Please choose an option (1 to 4):";

            int maxInputValue = 4;

            int filterNumber = receiveValidIntInRange(sr_MinInputValue, maxInputValue, message);
            List<string> licenseNumbers;

            if (filterNumber < maxInputValue)
            {
                licenseNumbers = sr_Garage.GetCurrentLicenseNumbersInGarageByState(filterNumber);
            }
            else
            {
                licenseNumbers = sr_Garage.GetCurrentLicenseNumbersInGarageByState(-1);
            }

            string licenseNumbersString = createLicenseNumberString(licenseNumbers);

            Console.Clear();
            Console.WriteLine(licenseNumbersString);
            promptUserToPressEnterToContinue();
        }

        private void changeStatusOfVehicle()
        {
            string licenseNumber = receiveLicenseNumberInGarage();
            bool userAsksToExit = licenseNumber == string.Empty;

            if (!userAsksToExit)
            {
                string message = @"Possible new states:
1) Being repaired
2) Repair is done
3) Paid

Please choose an option (1 to 3): ";

                int maxInputValue = 3;
                int newStateNumber = receiveValidIntInRange(sr_MinInputValue, maxInputValue, message);
                sr_Garage.ChangeVehicleState(licenseNumber, newStateNumber);
            }
        }

        private string receiveLicenseNumberInGarage()
        {
            Console.WriteLine("Please enter the license number of the vehicle:");

            string licenserNumber = getNonEmptyInput();
            bool isLicenseNumberInGarage = sr_Garage.IsLicenseNumberInGarage(licenserNumber);
            bool userWantsToKeepTrying = true;

            while (!isLicenseNumberInGarage && userWantsToKeepTrying)
            {
                Console.WriteLine("Vehicle is not in garage");

                userWantsToKeepTrying = checkIfUserWantsToCancel();

                if (userWantsToKeepTrying == false)
                {
                    licenserNumber = string.Empty;
                    break;
                }

                Console.WriteLine("Please try again:");
                licenserNumber = getNonEmptyInput();
                isLicenseNumberInGarage = sr_Garage.IsLicenseNumberInGarage(licenserNumber);
            }

            return licenserNumber;
        }

        private void inflateWheelsToMax()
        {
            string licenseNumber = receiveLicenseNumberInGarage();
            bool userAsksToQuit = licenseNumber == string.Empty;

            if (!userAsksToQuit)
            {
                sr_Garage.InflateWheelsToMax(licenseNumber);
            }
        }

        private void refuelVehicle()
        {
            string licenseNumber = receiveLicenseNumberInGarage();
            bool userAsksToQuit = licenseNumber == string.Empty;

            if (!userAsksToQuit)
            {
                string message = @"Please choose fuel type:
1) Soler
2) Octan 95
3) Octan 96
4) Octan 98

Please choose an option: ";

                int maxInputValue = 4;

                try
                {
                    int fuelType = receiveValidIntInRange(sr_MinInputValue, maxInputValue, message);

                    Console.WriteLine(@"What amount of fuel to add? (in litres)");
                    float amountOfFuel = getValidFloatNumber();

                    sr_Garage.RefuelVehicle(licenseNumber, fuelType, amountOfFuel);
                }
                catch (FormatException fe)
                {
                    Console.WriteLine(fe.Message);
                    promptUserToPressEnterToContinue();
                    refuelVehicle();
                }
                catch (ValueOutOfRangeException oor)
                {
                    Console.WriteLine(oor.Message);
                    promptUserToPressEnterToContinue();
                    refuelVehicle();
                }
                catch (ArgumentException ae)
                {
                    Console.WriteLine(ae.Message);
                    promptUserToPressEnterToContinue();
                    refuelVehicle();
                }
            }
        }

        private void chargeVehicle()
        {
            string licenseNumber = receiveLicenseNumberInGarage();
            bool userAsksToQiut = licenseNumber == string.Empty;
            if (!userAsksToQiut)
            {
                Console.WriteLine(@"Please type the amount of minutes to add:");
                float amountOfMinutesToCharge;

                try
                {
                    amountOfMinutesToCharge = getValidFloatNumber();
                    sr_Garage.ChargeVehicle(licenseNumber, amountOfMinutesToCharge);
                }
                catch (FormatException fe)
                {
                    Console.WriteLine(fe.Message);
                    promptUserToPressEnterToContinue();
                    chargeVehicle();
                }
                catch (ValueOutOfRangeException oor)
                {
                    Console.WriteLine(oor.Message);
                    promptUserToPressEnterToContinue();
                    chargeVehicle();
                }
                catch (ArgumentException ae)
                {
                    Console.WriteLine(ae.Message);
                    promptUserToPressEnterToContinue();
                    chargeVehicle();
                }
            }
        }

        private void displayVehicleInfo()
        {
            string licenseNumber = receiveLicenseNumberInGarage();
            bool userAsksToQuit = licenseNumber == string.Empty;

            if (!userAsksToQuit)
            {
                Console.WriteLine(sr_Garage.VehicleInfoToString(licenseNumber));
                promptUserToPressEnterToContinue();
            }
        }

        private int receiveValidIntInRange(int i_MinNumber, int i_MaxNumber, string i_Message)
        {
            Console.WriteLine(i_Message);
            return receiveValidIntInRange(i_MinNumber, i_MaxNumber);
        }

        private int receiveValidIntInRange(int i_MinNumber, int i_MaxNumber)
        {
            int inputNumber = 0;
            bool isValidInputNumber = false;
            bool isInputANumber;

            while (!isValidInputNumber)
            {
                string inputString = getNonEmptyInput();
                isInputANumber = int.TryParse(inputString, out inputNumber);
                if (isInputANumber)
                {
                    bool isNumberInRange = inputNumber >= i_MinNumber && inputNumber <= i_MaxNumber;
                    isValidInputNumber = isNumberInRange;
                }

                if (!isValidInputNumber)
                {
                    Console.WriteLine(string.Format("Input is invalid, please try again ({0} to {1}):", i_MinNumber, i_MaxNumber));
                }
            }

            return inputNumber;
        }

        private float receiveValidFloatInRange(float i_MinNumber, float i_MaxNumber, string i_Message)
        {
            float inputNumber = 0;
            bool isValidInputNumber = false;
            bool isInputANumber;

            Console.WriteLine(i_Message);
            while (!isValidInputNumber)
            {
                string inputString = getNonEmptyInput();
                isInputANumber = float.TryParse(inputString, out inputNumber);
                if (isInputANumber)
                {
                    bool isNumberInRange = inputNumber >= i_MinNumber && inputNumber <= i_MaxNumber;
                    isValidInputNumber = isNumberInRange;
                }

                if (!isValidInputNumber)
                {
                    Console.WriteLine(string.Format("Input is invalid, please try again ({0} to {1}):", i_MinNumber, i_MaxNumber));
                }
            }

            return inputNumber;
        }

        private void promptUserToPressEnterToContinue()
        {
            Console.WriteLine("Please press Enter to continue...");
            Console.ReadLine();
            Console.Clear();
        }

        private string createLicenseNumberString(List<string> io_LicenseNumbers)
        {
            StringBuilder licenseNumbersString = new StringBuilder();

            licenseNumbersString.AppendLine("Current license numbers in the garage:");

            if (io_LicenseNumbers.Count == 0)
            {
                licenseNumbersString.Append("There are no license numbers to display");
            }
            else
            {
                foreach (string licenseNumber in io_LicenseNumbers)
                {
                    licenseNumbersString.AppendLine(licenseNumber);
                }
            }

            return licenseNumbersString.ToString();
        }

        private bool checkIfUserWantsToCancel()
        {
            bool userWantsToKeepTrying;

            string message = @"Would you like to try again or go back to the main menu:
1) Try again
2) Go back";

            int maxInputValue = 2;

            int cancelNumber = this.receiveValidIntInRange(sr_MinInputValue, maxInputValue, message);
            if (cancelNumber == sr_MinInputValue)
            {
                userWantsToKeepTrying = true;
            }
            else
            {
                userWantsToKeepTrying = false;
            }

            return userWantsToKeepTrying;
        }

        private float getValidFloatNumber()
        {
            string input;
            bool isInputANumber;
            float inputNumber;

            do
            {
                input = getNonEmptyInput();
                isInputANumber = float.TryParse(input, out inputNumber);
                if (!isInputANumber)
                {
                    Console.WriteLine("Invalid input, please try again:");
                }
            } while (!isInputANumber);

            return inputNumber;
        }

        private string getNonEmptyInput()
        {
            string userInput = Console.ReadLine();
            
            while (userInput == string.Empty)
            {
                Console.WriteLine("Input can't be empty, please try again:");
                userInput = Console.ReadLine();
            }

            return userInput;
        }
        // $G$ CSS-999 (-3) Missing blank line before return method.
        private string getNonEmptyInput(string i_Message)
        {
            Console.WriteLine(i_Message);
            return getNonEmptyInput();
        }
    }
    // $G$ CSS-999 (-2) redundant blank line.
}
